import sys
from environment import MountainCar


def main(args):
    pass


if __name__ == "__main__":
    main(sys.argv)
